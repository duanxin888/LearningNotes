const { request } = require('../../utils/request.js')
const mock = require('../../utils/mock.js')
const { applyReferrerFromQuery } = require('../../utils/referrer.js')
const app = getApp()

function mapProduct(p) {
  if (!p) return null
  return {
    id: p.id,
    name: p.name,
    subtitle: p.subtitle || '',
    price: Number(p.price),
    image: p.image,
    tag: p.tag || ''
  }
}

Page({
  data: {
    shop: { name: '宋时方寸', notice: '', desc: '' },
    banners: [],
    products: [],
    entries: [
      { id: 'e1', label: '香事', icon: '香', cid: 1 },
      { id: 'e2', label: '茶器', icon: '茶', cid: 2 },
      { id: 'e3', label: '文房', icon: '文', cid: 3 },
      { id: 'e4', label: '雅物', icon: '雅', cid: 4 }
    ],
    loading: true
  },

  async onLoad(options) {
    applyReferrerFromQuery(options)
    await this.loadHome()
  },

  onShow() {
    if (app.syncCartBadges) app.syncCartBadges()
  },

  async loadHome() {
    try {
      const res = await request({ url: '/api/home' })
      const d = res.data || {}
      const shop = d.shop || {}
      this.setData({
        shop: {
          name: shop.name || '宋时方寸',
          notice: shop.notice || '',
          desc: shop.desc || ''
        },
        banners: (d.banners || []).map((b) => ({
          id: b.id,
          title: b.title,
          desc: b.desc || '',
          image: b.image
        })),
        products: (d.recommendProducts || []).map(mapProduct).filter(Boolean),
        loading: false
      })
    } catch (e) {
      this.setData({
        shop: {
          name: '宋时方寸',
          notice: '以物载道，以寸见山（离线演示数据）',
          desc: ''
        },
        banners: mock.banners,
        products: mock.products.slice(0, 4).map((p) => mapProduct({ ...p, id: p.id })),
        loading: false
      })
    }
  },

  onEntryTap(e) {
    const cid = e.currentTarget.dataset.cid
    wx.setStorageSync('pending_category', String(cid))
    wx.switchTab({ url: '/pages/category/category' })
  },

  onProductTap(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/product/detail?id=${id}` })
  },

  goSearch() {
    wx.navigateTo({ url: '/pages/goods/list' })
  },

  goCategory() {
    wx.switchTab({ url: '/pages/category/category' })
  }
})
