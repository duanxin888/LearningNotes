const { request } = require('../../utils/request.js')
const mock = require('../../utils/mock.js')
const app = getApp()

function mapProduct(p) {
  return {
    id: p.id,
    name: p.name,
    subtitle: p.subtitle || '',
    price: Number(p.price),
    image: p.image,
    tag: p.tag || ''
  }
}

Page({
  data: {
    categories: [],
    activeId: 1,
    list: []
  },

  onShow() {
    let activeId = this.data.activeId
    try {
      const pending = wx.getStorageSync('pending_category')
      if (pending !== undefined && pending !== '') {
        activeId = Number(pending) || activeId
        wx.removeStorageSync('pending_category')
      }
    } catch (e) {}
    this.setData({ activeId })
    this.bootstrap(activeId)
    if (app.syncCartBadges) app.syncCartBadges()
  },

  async bootstrap(activeId) {
    try {
      const [cRes, pRes] = await Promise.all([
        request({ url: '/api/categories' }),
        request({ url: '/api/products', data: { categoryId: activeId } })
      ])
      this.setData({
        categories: cRes.data || [],
        list: (pRes.data || []).map(mapProduct)
      })
    } catch (e) {
      this.setData({
        categories: mock.categories,
        list: mock.getProductsByCategory(activeId).map(mapProduct)
      })
    }
  },

  onSidebarTap(e) {
    const id = Number(e.currentTarget.dataset.id)
    this.setData({ activeId: id })
    this.loadList(id)
  },

  async loadList(categoryId) {
    try {
      const res = await request({ url: '/api/products', data: { categoryId } })
      this.setData({ list: (res.data || []).map(mapProduct) })
    } catch (e) {
      this.setData({
        list: mock.getProductsByCategory(categoryId).map(mapProduct)
      })
    }
  },

  onProductTap(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/product/detail?id=${id}` })
  }
})
