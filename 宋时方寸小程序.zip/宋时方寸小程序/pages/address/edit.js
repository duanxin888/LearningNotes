const { request } = require('../../utils/request.js')

Page({
  data: {
    id: null,
    contactName: '',
    contactPhone: '',
    province: '',
    city: '',
    district: '',
    detail: '',
    isDefault: true
  },

  onLoad(q) {
    if (q.id) {
      this.setData({ id: Number(q.id) })
      wx.setNavigationBarTitle({ title: '编辑地址' })
      this.loadOne(Number(q.id))
    } else {
      wx.setNavigationBarTitle({ title: '新增地址' })
    }
  },

  async loadOne(id) {
    try {
      const res = await request({ url: '/api/addresses' })
      const row = (res.data || []).find((a) => a.id === id)
      if (row) {
        this.setData({
          contactName: row.contactName,
          contactPhone: row.contactPhone,
          province: row.province,
          city: row.city,
          district: row.district,
          detail: row.detail,
          isDefault: !!row.isDefault
        })
      }
    } catch (e) {
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  onInput(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ [field]: e.detail.value })
  },

  onDefaultChange(e) {
    this.setData({ isDefault: e.detail.value.length > 0 })
  },

  async save() {
    const {
      id,
      contactName,
      contactPhone,
      province,
      city,
      district,
      detail,
      isDefault
    } = this.data
    if (!contactName || !contactPhone || !province || !city || !district || !detail) {
      wx.showToast({ title: '请填写完整', icon: 'none' })
      return
    }
    const body = {
      contactName,
      contactPhone,
      province,
      city,
      district,
      detail,
      isDefault
    }
    try {
      if (id) {
        await request({ url: `/api/addresses/${id}`, method: 'PUT', data: body })
      } else {
        await request({ url: '/api/addresses', method: 'POST', data: body })
      }
      wx.showToast({ title: '已保存', icon: 'success' })
      setTimeout(() => wx.navigateBack(), 400)
    } catch (e) {
      wx.showToast({ title: (e && e.message) || '保存失败', icon: 'none' })
    }
  }
})
