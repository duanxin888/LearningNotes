const { request } = require('../../utils/request.js')

Page({
  data: {
    list: []
  },

  onShow() {
    this.load()
  },

  async load() {
    try {
      const res = await request({ url: '/api/addresses' })
      this.setData({ list: res.data || [] })
    } catch (e) {
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  add() {
    wx.navigateTo({ url: '/pages/address/edit' })
  },

  edit(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/address/edit?id=${id}` })
  },

  async remove(e) {
    const id = e.currentTarget.dataset.id
    const r = await new Promise((resolve) => {
      wx.showModal({
        title: '删除地址',
        content: '确定删除该地址？',
        success: (res) => resolve(res.confirm)
      })
    })
    if (!r) return
    try {
      await request({ url: `/api/addresses/${id}`, method: 'DELETE' })
      wx.showToast({ title: '已删除', icon: 'success' })
      this.load()
    } catch (e) {
      wx.showToast({ title: '删除失败', icon: 'none' })
    }
  }
})
