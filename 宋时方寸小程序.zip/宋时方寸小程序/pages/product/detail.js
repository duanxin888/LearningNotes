const { request } = require('../../utils/request.js')
const mock = require('../../utils/mock.js')
const app = getApp()

Page({
  data: {
    product: null,
    loading: true
  },

  onLoad(q) {
    const id = Number(q.id)
    this.load(id)
  },

  async load(id) {
    this.setData({ loading: true })
    try {
      const res = await request({ url: `/api/products/${id}` })
      const p = res.data
      this.setData({
        product: {
          id: p.id,
          name: p.name,
          subtitle: p.subtitle || '',
          price: Number(p.price),
          image: p.image,
          tag: p.tag || '',
          detail: p.detail || '',
          stock: p.stock
        },
        loading: false
      })
    } catch (e) {
      const p = mock.getProductById(id)
      if (!p) {
        wx.showToast({ title: '商品不存在', icon: 'none' })
        setTimeout(() => wx.navigateBack(), 800)
        return
      }
      this.setData({ product: p, loading: false })
    }
  },

  addCart() {
    const p = this.data.product
    if (!p) return
    app.addToCart(
      { id: p.id, name: p.name, price: p.price, image: p.image },
      1
    )
    wx.showToast({ title: '已加入购物车', icon: 'success' })
  },

  buyNow() {
    const p = this.data.product
    if (!p) return
    app.addToCart(
      { id: p.id, name: p.name, price: p.price, image: p.image },
      1
    )
    wx.switchTab({ url: '/pages/cart/cart' })
  }
})
