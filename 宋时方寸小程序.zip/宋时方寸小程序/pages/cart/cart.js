const { ensureLogin } = require('../../utils/auth.js')
const app = getApp()

Page({
  data: {
    list: [],
    total: 0,
    empty: true
  },

  onShow() {
    this.refresh()
    if (app.syncCartBadges) app.syncCartBadges()
  },

  refresh() {
    const list = app.globalData.cart || []
    const total = app.getCartTotal ? app.getCartTotal() : 0
    this.setData({ list, total, empty: list.length === 0 })
  },

  inc(e) {
    const id = Number(e.currentTarget.dataset.id)
    const row = app.globalData.cart.find((i) => i.productId === id)
    if (!row) return
    app.setCartQty(id, row.qty + 1)
    this.refresh()
  },

  dec(e) {
    const id = Number(e.currentTarget.dataset.id)
    const row = app.globalData.cart.find((i) => i.productId === id)
    if (!row) return
    app.setCartQty(id, row.qty - 1)
    this.refresh()
  },

  async checkout() {
    if (this.data.empty) return
    try {
      await ensureLogin()
    } catch (e) {
      wx.showToast({ title: (e && e.message) || '登录失败', icon: 'none' })
      return
    }
    wx.navigateTo({ url: '/pages/order/confirm' })
  }
})
