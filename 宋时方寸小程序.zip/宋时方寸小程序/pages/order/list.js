const { request } = require('../../utils/request.js')

const STATUS_MAP = {
  pending_pay: '待支付',
  paid: '已支付',
  shipped: '已发货',
  completed: '已完成',
  cancelled: '已取消'
}

Page({
  data: {
    list: []
  },

  onShow() {
    this.load()
  },

  onPullDownRefresh() {
    this.load().finally(() => wx.stopPullDownRefresh())
  },

  async load() {
    if (!wx.getStorageSync('token')) {
      this.setData({ list: [] })
      return
    }
    try {
      const res = await request({ url: '/api/orders' })
      const rows = (res.data || []).map((o) => ({
        ...o,
        statusText: STATUS_MAP[o.status] || o.status
      }))
      this.setData({ list: rows })
    } catch (e) {
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  }
})
