const { request } = require('../../utils/request.js')
const { ensureLogin } = require('../../utils/auth.js')
const app = getApp()

Page({
  data: {
    addresses: [],
    selectedId: null,
    items: [],
    total: 0,
    submitting: false,
    hasUpline: false
  },

  async onShow() {
    await this.bootstrap()
  },

  async bootstrap() {
    try {
      await ensureLogin()
    } catch (e) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 600)
      return
    }
    const items = app.globalData.cart || []
    if (!items.length) {
      wx.showToast({ title: '购物车为空', icon: 'none' })
      setTimeout(() => wx.switchTab({ url: '/pages/cart/cart' }), 600)
      return
    }
    const total = items.reduce((s, i) => s + i.price * i.qty, 0)
    this.setData({ items, total })
    try {
      const meRes = await request({ url: '/api/auth/me' })
      const u = meRes.data
      this.setData({ hasUpline: !!(u && u.referredByUserId) })
    } catch (e) {
      this.setData({ hasUpline: false })
    }
    try {
      const res = await request({ url: '/api/addresses' })
      const list = res.data || []
      const def = list.find((a) => a.isDefault) || list[0]
      this.setData({
        addresses: list,
        selectedId: def ? def.id : null
      })
    } catch (e) {
      wx.showToast({ title: '请先在「我的」添加地址', icon: 'none' })
    }
  },

  onAddrChange(e) {
    const v = e.detail.value
    this.setData({ selectedId: v != null && v !== '' ? Number(v) : null })
  },

  goAddr() {
    wx.navigateTo({ url: '/pages/address/list' })
  },

  async submit() {
    if (this.data.submitting) return
    const addressId = this.data.selectedId
    if (!addressId) {
      wx.showToast({ title: '请选择收货地址', icon: 'none' })
      return
    }
    const items = this.data.items.map((i) => ({
      productId: i.productId,
      qty: i.qty
    }))
    this.setData({ submitting: true })
    try {
      const res = await request({
        url: '/api/orders',
        method: 'POST',
        data: { addressId, items }
      })
      const orderId = res.data.orderId
      app.clearCart()
      const prep = await request({
        url: `/api/orders/${orderId}/prepay`,
        method: 'POST'
      })
      const d = prep.data || {}
      if (!d.payAvailable) {
        wx.showModal({
          title: '下单成功',
          content: d.reason || '未配置微信支付，订单为待支付状态',
          showCancel: false,
          success: () => {
            wx.redirectTo({ url: '/pages/order/list' })
          }
        })
        return
      }
      const pay = d.payment
      await new Promise((resolve, reject) => {
        wx.requestPayment({
          timeStamp: pay.timeStamp,
          nonceStr: pay.nonceStr,
          package: pay.package,
          signType: pay.signType,
          paySign: pay.paySign,
          success: resolve,
          fail: reject
        })
      })
      wx.showToast({ title: '支付成功', icon: 'success' })
      setTimeout(() => {
        wx.redirectTo({ url: '/pages/order/list' })
      }, 400)
    } catch (e) {
      const msg =
        (e && e.message) ||
        (typeof e.errMsg === 'string' ? e.errMsg : '') ||
        '提交失败'
      if (msg.includes('cancel') || msg.includes('取消')) {
        wx.showToast({ title: '已取消支付', icon: 'none' })
        wx.redirectTo({ url: '/pages/order/list' })
      } else {
        wx.showToast({ title: msg, icon: 'none' })
      }
    } finally {
      this.setData({ submitting: false })
    }
  }
})
