const { request } = require('../../utils/request.js')

Page({
  data: {
    loading: true,
    isDistributor: false,
    userId: null,
    totalYuan: '0.00',
    commissionOrderCount: 0,
    list: []
  },

  onShow() {
    this.load()
  },

  async load() {
    this.setData({ loading: true })
    const token = wx.getStorageSync('token')
    if (!token) {
      this.setData({ loading: false, isDistributor: false })
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }
    try {
      const me = await request({ url: '/api/auth/me' })
      const u = me.data
      if (!u || u.role !== 'distributor') {
        this.setData({ loading: false, isDistributor: false, userId: u ? u.id : null })
        return
      }
      this.setData({ isDistributor: true, userId: u.id })
      const [sRes, cRes] = await Promise.all([
        request({ url: '/api/distributor/summary' }),
        request({ url: '/api/distributor/commissions' })
      ])
      this.setData({
        loading: false,
        totalYuan: sRes.data.totalYuan,
        commissionOrderCount: sRes.data.commissionOrderCount,
        list: cRes.data || []
      })
    } catch (e) {
      this.setData({ loading: false, isDistributor: false })
      wx.showToast({ title: (e && e.message) || '加载失败', icon: 'none' })
    }
  },

  onShareAppMessage() {
    const uid = this.data.userId
    return {
      title: '宋时方寸 · 精选好物',
      path: uid ? `/pages/index/index?rid=${uid}` : '/pages/index/index'
    }
  }
})
