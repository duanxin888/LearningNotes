const { request } = require('../../utils/request.js')
const mock = require('../../utils/mock.js')
const app = getApp()

function mapRow(p) {
  return {
    id: p.id,
    name: p.name,
    subtitle: p.subtitle || '',
    price: Number(p.price),
    image: p.image,
    tag: p.tag || ''
  }
}

Page({
  data: {
    keyword: '',
    list: [],
    loading: true
  },

  onShow() {
    if (app.syncCartBadges) app.syncCartBadges()
  },

  onLoad() {
    this.loadList()
  },

  onPullDownRefresh() {
    this.loadList().finally(() => wx.stopPullDownRefresh())
  },

  onSearchInput(e) {
    this.setData({ keyword: e.detail.value })
  },

  onSearchConfirm() {
    this.loadList()
  },

  async loadList() {
    this.setData({ loading: true })
    const kw = (this.data.keyword || '').trim()
    try {
      const res = await request({
        url: '/api/products',
        data: kw ? { keyword: kw } : {}
      })
      this.setData({
        list: (res.data || []).map(mapRow),
        loading: false
      })
    } catch (e) {
      let list = mock.products
      if (kw) {
        list = mock.products.filter(
          (p) => p.name.includes(kw) || (p.subtitle && p.subtitle.includes(kw))
        )
      }
      this.setData({
        list: list.map(mapRow),
        loading: false
      })
    }
  },

  onProductTap(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/product/detail?id=${id}` })
  }
})
