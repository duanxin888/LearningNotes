const { loginWithWx } = require('../../utils/auth.js')
const { request } = require('../../utils/request.js')
const app = getApp()

Page({
  data: {
    user: null,
    logged: false,
    isDistributor: false
  },

  onShow() {
    this.syncUser()
    if (app.syncCartBadges) app.syncCartBadges()
  },

  syncUser() {
    const token = wx.getStorageSync('token')
    if (!token) {
      this.setData({ user: null, logged: false, isDistributor: false })
      return
    }
    this.setData({ logged: true })
    request({ url: '/api/auth/me' })
      .then((res) => {
        const u = res.data
        this.setData({
          user: u
            ? {
                id: u.id,
                nickname: u.nickname || '微信用户',
                avatarUrl: u.avatarUrl || '',
                role: u.role || 'user'
              }
            : null,
          isDistributor: !!(u && u.role === 'distributor')
        })
        if (app.globalData) app.globalData.user = u
      })
      .catch(() => {
        this.setData({
          user: { nickname: '已登录', avatarUrl: '', role: 'user' },
          isDistributor: false
        })
      })
  },

  async onWxLogin() {
    try {
      await loginWithWx()
      wx.showToast({ title: '登录成功', icon: 'success' })
      this.syncUser()
    } catch (e) {
      wx.showToast({
        title: (e && e.message) || '登录失败',
        icon: 'none'
      })
    }
  },

  onGetProfile() {
    wx.getUserProfile({
      desc: '用于展示昵称与头像',
      success: async (r) => {
        const { nickName, avatarUrl } = r.userInfo
        try {
          await request({
            url: '/api/auth/profile',
            method: 'POST',
            data: { nickname: nickName, avatarUrl }
          })
          wx.showToast({ title: '已更新', icon: 'success' })
          this.syncUser()
        } catch (e) {
          wx.showToast({ title: '更新失败', icon: 'none' })
        }
      }
    })
  },

  goAddresses() {
    if (!wx.getStorageSync('token')) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }
    wx.navigateTo({ url: '/pages/address/list' })
  },

  goOrders() {
    if (!wx.getStorageSync('token')) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }
    wx.navigateTo({ url: '/pages/order/list' })
  },

  goDistributor() {
    if (!wx.getStorageSync('token')) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }
    wx.navigateTo({ url: '/pages/distributor/index' })
  }
})
