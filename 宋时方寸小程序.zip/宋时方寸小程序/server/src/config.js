require('dotenv').config()

module.exports = {
  port: Number(process.env.PORT || 3000),
  mysql: {
    host: process.env.MYSQL_HOST || '127.0.0.1',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'songshop',
    waitForConnections: true,
    connectionLimit: 10
  },
  wechat: {
    appId: process.env.WECHAT_APPID || '',
    appSecret: process.env.WECHAT_APP_SECRET || ''
  },
  jwtSecret: process.env.JWT_SECRET || 'dev-only-change-me',
  pay: {
    mchId: process.env.WECHAT_MCH_ID || '',
    payKey: process.env.WECHAT_PAY_KEY || '',
    notifyUrl: process.env.WECHAT_NOTIFY_URL || ''
  },
  admin: {
    username: process.env.ADMIN_USERNAME || 'admin',
    password: process.env.ADMIN_PASSWORD || 'admin123'
  }
}
