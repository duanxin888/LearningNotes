const crypto = require('crypto')
const axios = require('axios')
const config = require('../config')

function md5Upper(str) {
  return crypto.createHash('md5').update(str, 'utf8').digest('hex').toUpperCase()
}

function buildSign(params, key) {
  const keys = Object.keys(params)
    .filter((k) => params[k] !== '' && params[k] != null && k !== 'sign')
    .sort()
  const str = keys.map((k) => `${k}=${params[k]}`).join('&') + `&key=${key}`
  return md5Upper(str)
}

function parseWechatXml(xml) {
  const out = {}
  const re = /<(\w+)><!\[CDATA\[(.*?)\]\]><\/\1>/gs
  let m
  while ((m = re.exec(xml))) {
    out[m[1]] = m[2]
  }
  const re2 = /<(\w+)>([^<]*)<\/\1>/g
  while ((m = re2.exec(xml))) {
    if (out[m[1]] == null) out[m[1]] = m[2]
  }
  return out
}

async function unifiedOrderJsapi({
  openid,
  outTradeNo,
  body,
  totalFeeCent,
  spbillCreateIp,
  notifyUrl
}) {
  const { appId, mchId, payKey } = {
    appId: config.wechat.appId,
    mchId: config.pay.mchId,
    payKey: config.pay.payKey
  }
  if (!appId || !mchId || !payKey || !notifyUrl) {
    return { ok: false, reason: 'missing_pay_config' }
  }
  const nonce_str = Math.random().toString(36).slice(2, 18)
  const params = {
    appid: appId,
    mch_id: mchId,
    nonce_str,
    body: body.slice(0, 128),
    out_trade_no: outTradeNo,
    total_fee: String(totalFeeCent),
    spbill_create_ip: spbillCreateIp || '127.0.0.1',
    notify_url: notifyUrl,
    trade_type: 'JSAPI',
    openid
  }
  params.sign = buildSign(params, payKey)
  const xmlBody =
    '<xml>' +
    Object.entries(params)
      .map(([k, v]) => `<${k}><![CDATA[${v}]]></${k}>`)
      .join('') +
    '</xml>'

  const { data: xml } = await axios.post(
    'https://api.mch.weixin.qq.com/pay/unifiedorder',
    xmlBody,
    { headers: { 'Content-Type': 'text/xml' }, timeout: 15000 }
  )
  const r = parseWechatXml(xml)
  if (r.return_code !== 'SUCCESS') {
    return { ok: false, reason: r.return_msg || 'return_fail', raw: r }
  }
  if (r.result_code !== 'SUCCESS') {
    return { ok: false, reason: r.err_code_des || r.err_code || 'result_fail', raw: r }
  }
  return { ok: true, prepay_id: r.prepay_id, raw: r }
}

function buildMiniProgramPayParams(prepayId) {
  const { appId, payKey } = { appId: config.wechat.appId, payKey: config.pay.payKey }
  const timeStamp = String(Math.floor(Date.now() / 1000))
  const nonceStr = Math.random().toString(36).slice(2, 18)
  const pkg = `prepay_id=${prepayId}`
  const signType = 'MD5'
  const paySign = md5Upper(
    `appId=${appId}&nonceStr=${nonceStr}&package=${pkg}&signType=${signType}&timeStamp=${timeStamp}&key=${payKey}`
  )
  return {
    timeStamp,
    nonceStr,
    package: pkg,
    signType,
    paySign
  }
}

function verifyNotifySign(parsed, key) {
  const sign = parsed.sign
  const copy = { ...parsed }
  delete copy.sign
  return buildSign(copy, key) === sign
}

module.exports = {
  buildSign,
  parseWechatXml,
  unifiedOrderJsapi,
  buildMiniProgramPayParams,
  verifyNotifySign
}
