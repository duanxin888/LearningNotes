const jwt = require('jsonwebtoken')
const config = require('../config')

function adminAuth(req, res, next) {
  const h = req.headers.authorization || ''
  const token = h.startsWith('Bearer ') ? h.slice(7) : ''
  if (!token) {
    return res.status(401).json({ code: 401, message: '请先登录后台' })
  }
  try {
    const payload = jwt.verify(token, config.jwtSecret)
    if (!payload.admin) {
      return res.status(403).json({ code: 403, message: '无权访问' })
    }
    next()
  } catch (e) {
    return res.status(401).json({ code: 401, message: '登录已过期' })
  }
}

module.exports = { adminAuth }
