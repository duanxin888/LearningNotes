const jwt = require('jsonwebtoken')
const config = require('../config')

function requireAuth(req, res, next) {
  const h = req.headers.authorization || ''
  const token = h.startsWith('Bearer ') ? h.slice(7) : ''
  if (!token) {
    return res.status(401).json({ code: 401, message: '未登录' })
  }
  try {
    const payload = jwt.verify(token, config.jwtSecret)
    req.userId = payload.uid
    next()
  } catch (e) {
    return res.status(401).json({ code: 401, message: '登录已过期' })
  }
}

module.exports = { requireAuth }
