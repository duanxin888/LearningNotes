const path = require('path')
const express = require('express')
const cors = require('cors')
const config = require('./config')
const payNotify = require('./routes/payNotify')

const authRoutes = require('./routes/auth')
const homeRoutes = require('./routes/home')
const productRoutes = require('./routes/products')
const addressRoutes = require('./routes/addresses')
const orderRoutes = require('./routes/orders')
const distributorRoutes = require('./routes/distributor')
const adminApi = require('./routes/adminApi')

const app = express()
app.use(cors())

app.post(
  '/api/pay/notify',
  express.text({ type: ['text/xml', 'application/xml', 'text/plain', '*/*'] }),
  payNotify
)

app.use(express.json({ limit: '1mb' }))

app.use('/api', homeRoutes)
app.use('/api', productRoutes)
app.use('/api/auth', authRoutes)
app.use('/api', addressRoutes)
app.use('/api', orderRoutes)
app.use('/api', distributorRoutes)

app.use('/admin/api', adminApi)
app.use('/admin', express.static(path.join(__dirname, '../public/admin')))

app.get('/api/health', (_req, res) => {
  res.json({ code: 0, data: { ok: true } })
})

app.use((err, _req, res, _next) => {
  console.error(err)
  res.status(500).json({ code: 500, message: err.message || '服务器错误' })
})

app.listen(config.port, () => {
  console.log(`宋时方寸 API  http://127.0.0.1:${config.port}`)
})
