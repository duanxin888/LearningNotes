const express = require('express')
const { pool } = require('../db')

const router = express.Router()

router.get('/home', async (_req, res) => {
  try {
    const [[metaRows], [banners], [products]] = await Promise.all([
      pool.query(
        "SELECT `key`, `value` FROM shop_meta WHERE `key` IN ('shop_name','shop_notice','shop_desc')"
      ),
      pool.query(
        'SELECT id, title, subtitle AS `desc`, image FROM banners ORDER BY sort_order ASC, id ASC'
      ),
      pool.query(
        `SELECT id, category_id AS categoryId, name, subtitle, price_cent AS priceCent,
                ROUND(price_cent/100,2) AS price, image, tag
         FROM products ORDER BY id ASC LIMIT 8`
      )
    ])
    const shop = {}
    for (const row of metaRows) {
      shop[row.key === 'shop_name' ? 'name' : row.key === 'shop_notice' ? 'notice' : 'desc'] =
        row.value
    }
    res.json({
      code: 0,
      data: {
        shop,
        banners,
        recommendProducts: products
      }
    })
  } catch (e) {
    console.error(e)
    res.status(500).json({ code: 500, message: '加载首页失败' })
  }
})

module.exports = router
