const express = require('express')
const { pool } = require('../db')
const { requireAuth } = require('../middleware/requireAuth')
const config = require('../config')
const {
  unifiedOrderJsapi,
  buildMiniProgramPayParams
} = require('../services/wxpay')

const router = express.Router()

function genOutTradeNo() {
  return `SF${Date.now()}${Math.random().toString(36).slice(2, 8).toUpperCase()}`
}

router.post('/orders', requireAuth, async (req, res) => {
  const { addressId, items } = req.body || {}
  if (!addressId || !Array.isArray(items) || !items.length) {
    return res.status(400).json({ code: 400, message: '参数错误' })
  }
  const [addrs] = await pool.query(
    `SELECT id, contact_name, contact_phone, province, city, district, detail
     FROM user_addresses WHERE id = ? AND user_id = ?`,
    [addressId, req.userId]
  )
  if (!addrs.length) {
    return res.status(400).json({ code: 400, message: '收货地址无效' })
  }
  const addr = addrs[0]
  const addressJson = {
    contactName: addr.contact_name,
    contactPhone: addr.contact_phone,
    province: addr.province,
    city: addr.city,
    district: addr.district,
    detail: addr.detail
  }

  const conn = await pool.getConnection()
  try {
    await conn.beginTransaction()
    await conn.query('SELECT id FROM users WHERE id = ? FOR UPDATE', [req.userId])
    const [buyers] = await conn.query(
      `SELECT u.referred_by_user_id AS refId, r.role AS refRole, u.role AS buyerRole
       FROM users u
       LEFT JOIN users r ON r.id = u.referred_by_user_id
       WHERE u.id = ?`,
      [req.userId]
    )
    let referrerUserId = null
    if (buyers.length) {
      const b = buyers[0]
      const buyerIsUser = b.buyerRole !== 'distributor'
      if (buyerIsUser && b.refId && b.refRole === 'distributor') {
        referrerUserId = b.refId
      }
    }

    let totalCent = 0
    const lines = []
    for (const it of items) {
      const pid = Number(it.productId)
      const qty = Number(it.qty)
      if (!pid || !qty || qty < 1) {
        throw Object.assign(new Error('bad_item'), { status: 400 })
      }
      const [prows] = await conn.query(
        'SELECT id, name, price_cent, stock, image FROM products WHERE id = ? FOR UPDATE',
        [pid]
      )
      if (!prows.length) {
        throw Object.assign(new Error('商品不存在'), { status: 400 })
      }
      const p = prows[0]
      if (p.stock < qty) {
        throw Object.assign(new Error(`「${p.name}」库存不足`), { status: 400 })
      }
      totalCent += p.price_cent * qty
      lines.push({ p, qty })
    }

    const outTradeNo = genOutTradeNo()
    const [or] = await conn.query(
      `INSERT INTO orders (user_id, out_trade_no, status, total_cent, address_json, referrer_user_id)
       VALUES (?,?,?,?,?,?)`,
      [
        req.userId,
        outTradeNo,
        'pending_pay',
        totalCent,
        JSON.stringify(addressJson),
        referrerUserId
      ]
    )
    const orderId = or.insertId
    for (const { p, qty } of lines) {
      await conn.query(
        `INSERT INTO order_items (order_id, product_id, product_name, price_cent, qty, image)
         VALUES (?,?,?,?,?,?)`,
        [orderId, p.id, p.name, p.price_cent, qty, p.image]
      )
      await conn.query('UPDATE products SET stock = stock - ? WHERE id = ?', [qty, p.id])
    }
    await conn.commit()
    res.json({
      code: 0,
      data: { orderId, outTradeNo, totalCent, totalYuan: (totalCent / 100).toFixed(2) }
    })
  } catch (e) {
    await conn.rollback()
    const status = e.status || 500
    res.status(status).json({ code: status, message: e.message || '下单失败' })
  } finally {
    conn.release()
  }
})

router.post('/orders/:id/prepay', requireAuth, async (req, res) => {
  const orderId = Number(req.params.id)
  const [users] = await pool.query('SELECT openid FROM users WHERE id = ?', [req.userId])
  if (!users.length || !users[0].openid) {
    return res.status(400).json({ code: 400, message: '用户 openid 缺失' })
  }
  const openid = users[0].openid
  const [orders] = await pool.query(
    'SELECT * FROM orders WHERE id = ? AND user_id = ?',
    [orderId, req.userId]
  )
  if (!orders.length) {
    return res.status(404).json({ code: 404, message: '订单不存在' })
  }
  const order = orders[0]
  if (order.status !== 'pending_pay') {
    return res.status(400).json({ code: 400, message: '订单状态不可支付' })
  }

  const payCfgOk =
    config.pay.mchId && config.pay.payKey && config.pay.notifyUrl && config.wechat.appId
  if (!payCfgOk) {
    return res.json({
      code: 0,
      data: {
        payAvailable: false,
        reason: '未配置微信支付商户号、API 密钥或 notify_url',
        orderId
      }
    })
  }

  const uo = await unifiedOrderJsapi({
    openid,
    outTradeNo: order.out_trade_no,
    body: '宋时方寸-订单',
    totalFeeCent: order.total_cent,
    spbillCreateIp: req.ip || '127.0.0.1',
    notifyUrl: config.pay.notifyUrl
  })
  if (!uo.ok) {
    return res.status(502).json({
      code: 502,
      message: uo.reason || '统一下单失败',
      detail: uo.raw
    })
  }
  await pool.query('UPDATE orders SET prepay_id = ? WHERE id = ?', [uo.prepay_id, orderId])
  const payment = buildMiniProgramPayParams(uo.prepay_id)
  res.json({
    code: 0,
    data: {
      payAvailable: true,
      orderId,
      appId: config.wechat.appId,
      payment
    }
  })
})

router.get('/orders', requireAuth, async (req, res) => {
  const [rows] = await pool.query(
    `SELECT id, out_trade_no AS outTradeNo, status, total_cent AS totalCent,
            ROUND(total_cent/100,2) AS totalYuan, created_at AS createdAt
     FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 50`,
    [req.userId]
  )
  res.json({ code: 0, data: rows })
})

router.get('/orders/:id', requireAuth, async (req, res) => {
  const id = Number(req.params.id)
  const [orders] = await pool.query(
    `SELECT id, out_trade_no AS outTradeNo, status, total_cent AS totalCent,
            ROUND(total_cent/100,2) AS totalYuan, address_json AS address, created_at AS createdAt
     FROM orders WHERE id = ? AND user_id = ?`,
    [id, req.userId]
  )
  if (!orders.length) {
    return res.status(404).json({ code: 404, message: '订单不存在' })
  }
  const [items] = await pool.query(
    `SELECT product_id AS productId, product_name AS name, price_cent AS priceCent,
            ROUND(price_cent/100,2) AS price, qty, image
     FROM order_items WHERE order_id = ?`,
    [id]
  )
  res.json({ code: 0, data: { ...orders[0], items } })
})

module.exports = router
