const express = require('express')
const axios = require('axios')
const jwt = require('jsonwebtoken')
const { pool } = require('../db')
const config = require('../config')
const { requireAuth } = require('../middleware/requireAuth')

const router = express.Router()

function userPublic(u) {
  if (!u) return null
  return {
    id: u.id,
    nickname: u.nickname,
    avatarUrl: u.avatar_url,
    role: u.role || 'user',
    referredByUserId: u.referred_by_user_id != null ? u.referred_by_user_id : null
  }
}

async function resolveDistributorId(candidateId, excludeUserId) {
  const rid = Number(candidateId)
  if (!rid || rid < 1) return null
  if (excludeUserId != null && rid === excludeUserId) return null
  const [ref] = await pool.query('SELECT id, role FROM users WHERE id = ?', [rid])
  if (!ref.length || ref[0].role !== 'distributor') return null
  return rid
}

router.post('/wx-login', async (req, res) => {
  const { code, referrerId } = req.body || {}
  if (!code) {
    return res.status(400).json({ code: 400, message: '缺少 code' })
  }
  if (!config.wechat.appId || !config.wechat.appSecret) {
    return res.status(500).json({ code: 500, message: '服务端未配置 WECHAT_APPID / WECHAT_APP_SECRET' })
  }
  try {
    const { data } = await axios.get('https://api.weixin.qq.com/sns/jscode2session', {
      params: {
        appid: config.wechat.appId,
        secret: config.wechat.appSecret,
        js_code: code,
        grant_type: 'authorization_code'
      },
      timeout: 10000
    })
    if (data.errcode) {
      return res.status(400).json({ code: 400, message: data.errmsg || 'code 无效' })
    }
    const { openid, unionid } = data
    const [rows] = await pool.query('SELECT * FROM users WHERE openid = ? LIMIT 1', [openid])
    let user
    if (rows.length) {
      user = rows[0]
      const canBindUpline = user.role !== 'distributor' && user.referred_by_user_id == null
      if (canBindUpline) {
        const distId = await resolveDistributorId(referrerId, user.id)
        if (distId) {
          await pool.query(
            'UPDATE users SET referred_by_user_id = ? WHERE id = ? AND referred_by_user_id IS NULL AND role <> ?',
            [distId, user.id, 'distributor']
          )
          const [u2] = await pool.query('SELECT * FROM users WHERE id = ?', [user.id])
          user = u2[0]
        }
      }
    } else {
      const distId = await resolveDistributorId(referrerId, null)
      const [r] = await pool.query(
        'INSERT INTO users (openid, unionid, referred_by_user_id) VALUES (?, ?, ?)',
        [openid, unionid || null, distId]
      )
      const [u] = await pool.query('SELECT * FROM users WHERE id = ?', [r.insertId])
      user = u[0]
    }
    const token = jwt.sign({ uid: user.id }, config.jwtSecret, { expiresIn: '30d' })
    res.json({
      code: 0,
      data: {
        token,
        user: userPublic(user)
      }
    })
  } catch (e) {
    console.error(e)
    res.status(500).json({ code: 500, message: '登录失败' })
  }
})

router.post('/bind-referrer', requireAuth, async (req, res) => {
  const rid = Number((req.body || {}).referrerId)
  if (!rid) {
    return res.status(400).json({ code: 400, message: '缺少有效 referrerId' })
  }
  const [meRows] = await pool.query(
    'SELECT id, referred_by_user_id, role FROM users WHERE id = ?',
    [req.userId]
  )
  if (!meRows.length) {
    return res.status(404).json({ code: 404, message: '用户不存在' })
  }
  if (meRows[0].role === 'distributor') {
    return res.json({ code: 0, data: { bound: false, reason: 'distributor' } })
  }
  if (meRows[0].referred_by_user_id != null) {
    return res.json({ code: 0, data: { bound: false, reason: 'already' } })
  }
  const distId = await resolveDistributorId(rid, req.userId)
  if (!distId) {
    return res.status(400).json({ code: 400, message: '无效的分销商或不能绑定自己' })
  }
  await pool.query(
    'UPDATE users SET referred_by_user_id = ? WHERE id = ? AND referred_by_user_id IS NULL AND role <> ?',
    [distId, req.userId, 'distributor']
  )
  return res.json({ code: 0, data: { bound: true } })
})

router.post('/profile', requireAuth, async (req, res) => {
  const { nickname, avatarUrl } = req.body || {}
  await pool.query(
    'UPDATE users SET nickname = COALESCE(?, nickname), avatar_url = COALESCE(?, avatar_url) WHERE id = ?',
    [nickname || null, avatarUrl || null, req.userId]
  )
  const [rows] = await pool.query(
    'SELECT id, nickname, avatar_url AS avatarUrl, role, referred_by_user_id AS referredByUserId FROM users WHERE id = ?',
    [req.userId]
  )
  res.json({ code: 0, data: rows[0] })
})

router.get('/me', requireAuth, async (req, res) => {
  const [rows] = await pool.query(
    'SELECT id, nickname, avatar_url AS avatarUrl, role, referred_by_user_id AS referredByUserId FROM users WHERE id = ?',
    [req.userId]
  )
  res.json({ code: 0, data: rows[0] || null })
})

module.exports = router
