const { pool } = require('../db')
const config = require('../config')
const { parseWechatXml, verifyNotifySign } = require('../services/wxpay')

async function loadCommissionRate(conn) {
  const [r] = await conn.query(
    "SELECT `value` FROM shop_meta WHERE `key` = 'commission_rate_percent' LIMIT 1"
  )
  let p = r.length ? parseInt(r[0].value, 10) : 10
  if (Number.isNaN(p) || p < 0) p = 0
  if (p > 100) p = 100
  return p
}

async function payNotify(req, res) {
  const xml = req.body || ''
  let parsed
  try {
    parsed = parseWechatXml(typeof xml === 'string' ? xml : String(xml))
  } catch (e) {
    return res.type('application/xml').send(failXml('FAIL', 'parse'))
  }
  if (!config.pay.payKey) {
    return res.type('application/xml').send(failXml('FAIL', 'no key'))
  }
  if (!verifyNotifySign(parsed, config.pay.payKey)) {
    return res.type('application/xml').send(failXml('FAIL', 'sign'))
  }
  if (parsed.return_code !== 'SUCCESS' || parsed.result_code !== 'SUCCESS') {
    return res.type('application/xml').send(failXml('FAIL', 'result'))
  }
  const outTradeNo = parsed.out_trade_no
  const transactionId = parsed.transaction_id
  const conn = await pool.getConnection()
  try {
    await conn.beginTransaction()
    const [rows] = await conn.query(
      'SELECT id, status, total_cent, referrer_user_id FROM orders WHERE out_trade_no = ? FOR UPDATE',
      [outTradeNo]
    )
    if (!rows.length) {
      await conn.rollback()
      return res.type('application/xml').send(failXml('FAIL', 'no order'))
    }
    const o = rows[0]
    if (o.status === 'pending_pay') {
      await conn.query(
        'UPDATE orders SET status = ?, transaction_id = ?, paid_at = NOW() WHERE id = ?',
        ['paid', transactionId, o.id]
      )
      if (o.referrer_user_id) {
        const rate = await loadCommissionRate(conn)
        const amountCent = Math.floor((Number(o.total_cent) * rate) / 100)
        if (amountCent > 0) {
          try {
            await conn.query(
              `INSERT INTO commissions (order_id, distributor_user_id, amount_cent, rate_used, status)
               VALUES (?,?,?,?, 'accrued')`,
              [o.id, o.referrer_user_id, amountCent, rate]
            )
          } catch (insErr) {
            if (insErr.code !== 'ER_DUP_ENTRY') throw insErr
          }
        }
      }
    }
    await conn.commit()
  } catch (e) {
    await conn.rollback()
    console.error(e)
    return res.type('application/xml').send(failXml('FAIL', 'db'))
  } finally {
    conn.release()
  }
  return res.type('application/xml').send(successXml())
}

function successXml() {
  return '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>'
}

function failXml(code, msg) {
  return `<xml><return_code><![CDATA[${code}]]></return_code><return_msg><![CDATA[${msg}]]></return_msg></xml>`
}

module.exports = payNotify
