const express = require('express')
const crypto = require('crypto')
const jwt = require('jsonwebtoken')
const { pool } = require('../db')
const config = require('../config')
const { adminAuth } = require('../middleware/adminAuth')

const router = express.Router()

function hashPass(s) {
  return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex')
}

function safeEqualStr(a, b) {
  const x = Buffer.from(String(a), 'utf8')
  const y = Buffer.from(String(b), 'utf8')
  if (x.length !== y.length) return false
  return crypto.timingSafeEqual(x, y)
}

router.post('/login', (req, res) => {
  const { username, password } = req.body || {}
  const u = config.admin.username
  const p = config.admin.password
  const okUser = safeEqualStr(hashPass(username || ''), hashPass(u))
  const okPass = safeEqualStr(hashPass(password || ''), hashPass(p))
  if (!okUser || !okPass) {
    return res.status(401).json({ code: 401, message: '账号或密码错误' })
  }
  const token = jwt.sign({ admin: true }, config.jwtSecret, { expiresIn: '12h' })
  res.json({ code: 0, data: { token } })
})

router.use(adminAuth)

router.get('/stats', async (_req, res) => {
  const [[{ c: orderCount }], [{ c: productCount }], [{ c: pendingPay }]] =
    await Promise.all([
      pool.query('SELECT COUNT(*) AS c FROM orders'),
      pool.query('SELECT COUNT(*) AS c FROM products'),
      pool.query("SELECT COUNT(*) AS c FROM orders WHERE status = 'pending_pay'")
    ])
  res.json({
    code: 0,
    data: {
      orderCount: orderCount || 0,
      productCount: productCount || 0,
      pendingPay: pendingPay || 0
    }
  })
})

router.get('/shop', async (_req, res) => {
  const [rows] = await pool.query(
    "SELECT `key`, `value` FROM shop_meta WHERE `key` IN ('shop_name','shop_notice','shop_desc','commission_rate_percent')"
  )
  const shop = { name: '', notice: '', desc: '', commissionRatePercent: 10 }
  for (const row of rows) {
    if (row.key === 'shop_name') shop.name = row.value
    if (row.key === 'shop_notice') shop.notice = row.value
    if (row.key === 'shop_desc') shop.desc = row.value
    if (row.key === 'commission_rate_percent') {
      const n = parseInt(row.value, 10)
      shop.commissionRatePercent = Number.isNaN(n) ? 10 : n
    }
  }
  res.json({ code: 0, data: shop })
})

router.put('/shop', async (req, res) => {
  const { name, notice, desc, commissionRatePercent } = req.body || {}
  const conn = await pool.getConnection()
  try {
    if (name != null) {
      await conn.query(
        'INSERT INTO shop_meta (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?',
        ['shop_name', name, name]
      )
    }
    if (notice != null) {
      await conn.query(
        'INSERT INTO shop_meta (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?',
        ['shop_notice', notice, notice]
      )
    }
    if (desc != null) {
      await conn.query(
        'INSERT INTO shop_meta (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?',
        ['shop_desc', desc, desc]
      )
    }
    if (commissionRatePercent != null) {
      let p = parseInt(String(commissionRatePercent), 10)
      if (Number.isNaN(p) || p < 0) p = 0
      if (p > 100) p = 100
      await conn.query(
        'INSERT INTO shop_meta (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?',
        ['commission_rate_percent', String(p), String(p)]
      )
    }
    res.json({ code: 0, data: true })
  } finally {
    conn.release()
  }
})

router.get('/categories', async (_req, res) => {
  const [rows] = await pool.query(
    'SELECT id, name, sort_order AS sortOrder FROM categories ORDER BY sort_order, id'
  )
  res.json({ code: 0, data: rows })
})

router.post('/categories', async (req, res) => {
  const { name, sortOrder } = req.body || {}
  if (!name) return res.status(400).json({ code: 400, message: '名称必填' })
  const [r] = await pool.query(
    'INSERT INTO categories (name, sort_order) VALUES (?,?)',
    [name, Number(sortOrder) || 0]
  )
  res.json({ code: 0, data: { id: r.insertId } })
})

router.put('/categories/:id', async (req, res) => {
  const id = Number(req.params.id)
  const [rows] = await pool.query('SELECT * FROM categories WHERE id = ?', [id])
  if (!rows.length) {
    return res.status(404).json({ code: 404, message: '分类不存在' })
  }
  const cur = rows[0]
  const b = req.body || {}
  const name = b.name != null ? b.name : cur.name
  const sortOrder = b.sortOrder != null ? Number(b.sortOrder) : cur.sort_order
  await pool.query('UPDATE categories SET name = ?, sort_order = ? WHERE id = ?', [name, sortOrder, id])
  res.json({ code: 0, data: true })
})

router.get('/products', async (_req, res) => {
  const [rows] = await pool.query(
    `SELECT id, category_id AS categoryId, name, subtitle,
            price_cent AS priceCent, ROUND(price_cent/100,2) AS priceYuan,
            image, stock, tag, detail
     FROM products ORDER BY id DESC`
  )
  res.json({ code: 0, data: rows })
})

router.post('/products', async (req, res) => {
  const b = req.body || {}
  const {
    categoryId,
    name,
    subtitle,
    priceYuan,
    priceCent,
    image,
    stock,
    tag,
    detail
  } = b
  if (!categoryId || !name || !image) {
    return res.status(400).json({ code: 400, message: '分类、名称、图片必填' })
  }
  let cent = priceCent != null ? Number(priceCent) : null
  if (cent == null && priceYuan != null) {
    cent = Math.round(Number(priceYuan) * 100)
  }
  if (cent == null || cent < 0) {
    return res.status(400).json({ code: 400, message: '价格无效' })
  }
  const [r] = await pool.query(
    `INSERT INTO products (category_id, name, subtitle, price_cent, image, stock, tag, detail)
     VALUES (?,?,?,?,?,?,?,?)`,
    [
      categoryId,
      name,
      subtitle || null,
      cent,
      image,
      stock != null ? Number(stock) : 999,
      tag || null,
      detail || null
    ]
  )
  res.json({ code: 0, data: { id: r.insertId } })
})

router.put('/products/:id', async (req, res) => {
  const id = Number(req.params.id)
  const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id])
  if (!rows.length) {
    return res.status(404).json({ code: 404, message: '商品不存在' })
  }
  const cur = rows[0]
  const b = req.body || {}
  let price_cent = cur.price_cent
  if (b.priceYuan != null && b.priceYuan !== '') {
    price_cent = Math.round(Number(b.priceYuan) * 100)
  }
  if (b.priceCent != null && b.priceCent !== '') {
    price_cent = Number(b.priceCent)
  }
  const next = {
    category_id: b.categoryId != null ? b.categoryId : cur.category_id,
    name: b.name != null ? b.name : cur.name,
    subtitle: b.subtitle !== undefined ? b.subtitle : cur.subtitle,
    price_cent,
    image: b.image != null ? b.image : cur.image,
    stock: b.stock != null ? Number(b.stock) : cur.stock,
    tag: b.tag !== undefined ? b.tag : cur.tag,
    detail: b.detail !== undefined ? b.detail : cur.detail
  }
  await pool.query(
    `UPDATE products SET category_id=?, name=?, subtitle=?, price_cent=?, image=?, stock=?, tag=?, detail=? WHERE id=?`,
    [
      next.category_id,
      next.name,
      next.subtitle,
      next.price_cent,
      next.image,
      next.stock,
      next.tag,
      next.detail,
      id
    ]
  )
  res.json({ code: 0, data: true })
})

router.delete('/products/:id', async (req, res) => {
  const id = Number(req.params.id)
  await pool.query('DELETE FROM products WHERE id = ?', [id])
  res.json({ code: 0, data: true })
})

router.get('/banners', async (_req, res) => {
  const [rows] = await pool.query(
    'SELECT id, title, subtitle, image, sort_order AS sortOrder FROM banners ORDER BY sort_order, id'
  )
  res.json({ code: 0, data: rows })
})

router.post('/banners', async (req, res) => {
  const { title, subtitle, image, sortOrder } = req.body || {}
  if (!title || !image) {
    return res.status(400).json({ code: 400, message: '标题与图片必填' })
  }
  const [r] = await pool.query(
    'INSERT INTO banners (title, subtitle, image, sort_order) VALUES (?,?,?,?)',
    [title, subtitle || null, image, Number(sortOrder) || 0]
  )
  res.json({ code: 0, data: { id: r.insertId } })
})

router.put('/banners/:id', async (req, res) => {
  const id = Number(req.params.id)
  const [rows] = await pool.query('SELECT * FROM banners WHERE id = ?', [id])
  if (!rows.length) {
    return res.status(404).json({ code: 404, message: '轮播不存在' })
  }
  const cur = rows[0]
  const b = req.body || {}
  const title = b.title != null ? b.title : cur.title
  const subtitle = b.subtitle !== undefined ? b.subtitle : cur.subtitle
  const image = b.image != null ? b.image : cur.image
  const sortOrder = b.sortOrder != null ? Number(b.sortOrder) : cur.sort_order
  await pool.query(
    'UPDATE banners SET title=?, subtitle=?, image=?, sort_order=? WHERE id=?',
    [title, subtitle, image, sortOrder, id]
  )
  res.json({ code: 0, data: true })
})

router.delete('/banners/:id', async (req, res) => {
  await pool.query('DELETE FROM banners WHERE id = ?', [Number(req.params.id)])
  res.json({ code: 0, data: true })
})

router.get('/orders', async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1)
  const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20))
  const offset = (page - 1) * limit
  const [rows] = await pool.query(
    `SELECT o.id, o.out_trade_no AS outTradeNo, o.status, o.total_cent AS totalCent,
            ROUND(o.total_cent/100,2) AS totalYuan, o.created_at AS createdAt,
            u.nickname AS userNickname
     FROM orders o
     LEFT JOIN users u ON u.id = o.user_id
     ORDER BY o.id DESC
     LIMIT ? OFFSET ?`,
    [limit, offset]
  )
  const [[{ c: total }]] = await pool.query('SELECT COUNT(*) AS c FROM orders')
  res.json({ code: 0, data: { list: rows, total, page, limit } })
})

router.get('/orders/:id', async (req, res) => {
  const id = Number(req.params.id)
  const [orders] = await pool.query(
    `SELECT o.*, ROUND(o.total_cent/100,2) AS totalYuan, u.nickname AS userNickname
     FROM orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.id = ?`,
    [id]
  )
  if (!orders.length) {
    return res.status(404).json({ code: 404, message: '订单不存在' })
  }
  const [items] = await pool.query(
    `SELECT product_id AS productId, product_name AS name, price_cent AS priceCent,
            ROUND(price_cent/100,2) AS priceYuan, qty, image
     FROM order_items WHERE order_id = ?`,
    [id]
  )
  const o = orders[0]
  res.json({
    code: 0,
    data: {
      id: o.id,
      outTradeNo: o.out_trade_no,
      status: o.status,
      totalYuan: o.totalYuan,
      address: o.address_json,
      createdAt: o.created_at,
      paidAt: o.paid_at,
      userNickname: o.userNickname,
      items
    }
  })
})

router.patch('/orders/:id/status', async (req, res) => {
  const id = Number(req.params.id)
  const { status } = req.body || {}
  const allowed = ['pending_pay', 'paid', 'shipped', 'completed', 'cancelled']
  if (!allowed.includes(status)) {
    return res.status(400).json({ code: 400, message: '状态不合法' })
  }
  await pool.query('UPDATE orders SET status = ? WHERE id = ?', [status, id])
  res.json({ code: 0, data: true })
})

router.get('/users', async (req, res) => {
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 80))
  const q = (req.query.q || '').trim()
  let sql = `SELECT id, nickname, openid, role, referred_by_user_id AS referredByUserId, created_at AS createdAt FROM users`
  const params = []
  if (q) {
    const num = parseInt(q, 10)
    if (!Number.isNaN(num) && String(num) === q) {
      sql += ' WHERE id = ?'
      params.push(num)
    } else {
      sql += ' WHERE nickname LIKE ? OR openid LIKE ?'
      params.push(`%${q}%`, `%${q}%`)
    }
  }
  sql += ' ORDER BY id DESC LIMIT ?'
  params.push(limit)
  const [rows] = await pool.query(sql, params)
  res.json({ code: 0, data: rows })
})

router.put('/users/:id/role', async (req, res) => {
  const id = Number(req.params.id)
  const { role } = req.body || {}
  if (role !== 'user' && role !== 'distributor') {
    return res.status(400).json({ code: 400, message: 'role 须为 user 或 distributor' })
  }
  if (role === 'distributor') {
    await pool.query(
      'UPDATE users SET role = ?, referred_by_user_id = NULL WHERE id = ?',
      ['distributor', id]
    )
  } else {
    await pool.query('UPDATE users SET role = ? WHERE id = ?', [role, id])
  }
  res.json({ code: 0, data: true })
})

router.get('/commissions', async (req, res) => {
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 50))
  const [rows] = await pool.query(
    `SELECT c.id, c.order_id AS orderId, o.out_trade_no AS outTradeNo,
            c.distributor_user_id AS distributorUserId,
            u.nickname AS distributorNickname,
            c.amount_cent AS amountCent,
            ROUND(c.amount_cent/100,2) AS amountYuan,
            c.rate_used AS ratePercent,
            c.status, c.created_at AS createdAt
     FROM commissions c
     JOIN orders o ON o.id = c.order_id
     LEFT JOIN users u ON u.id = c.distributor_user_id
     ORDER BY c.id DESC
     LIMIT ?`,
    [limit]
  )
  res.json({ code: 0, data: rows })
})

module.exports = router
