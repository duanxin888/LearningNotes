const express = require('express')
const { pool } = require('../db')

const router = express.Router()

router.get('/categories', async (_req, res) => {
  const [rows] = await pool.query(
    'SELECT id, name FROM categories ORDER BY sort_order ASC, id ASC'
  )
  res.json({ code: 0, data: rows })
})

router.get('/products', async (req, res) => {
  const categoryId = req.query.categoryId ? Number(req.query.categoryId) : null
  const kw = (req.query.keyword || '').trim()
  let sql = `SELECT id, category_id AS categoryId, name, subtitle,
              ROUND(price_cent/100,2) AS price, price_cent AS priceCent, image, tag, stock
              FROM products WHERE 1=1`
  const params = []
  if (categoryId) {
    sql += ' AND category_id = ?'
    params.push(categoryId)
  }
  if (kw) {
    sql += ' AND (name LIKE ? OR subtitle LIKE ?)'
    params.push(`%${kw}%`, `%${kw}%`)
  }
  sql += ' ORDER BY id ASC'
  const [rows] = await pool.query(sql, params)
  res.json({ code: 0, data: rows })
})

router.get('/products/:id', async (req, res) => {
  const id = Number(req.params.id)
  const [rows] = await pool.query(
    `SELECT id, category_id AS categoryId, name, subtitle, detail,
            ROUND(price_cent/100,2) AS price, price_cent AS priceCent, image, tag, stock
     FROM products WHERE id = ?`,
    [id]
  )
  if (!rows.length) {
    return res.status(404).json({ code: 404, message: '商品不存在' })
  }
  res.json({ code: 0, data: rows[0] })
})

module.exports = router
