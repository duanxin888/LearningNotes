const express = require('express')
const { pool } = require('../db')
const { requireAuth } = require('../middleware/requireAuth')

const router = express.Router()
router.use(requireAuth)

router.get('/addresses', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT id, contact_name AS contactName, contact_phone AS contactPhone,
            province, city, district, detail, is_default AS isDefault
     FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC`,
    [req.userId]
  )
  res.json({ code: 0, data: rows })
})

router.post('/addresses', async (req, res) => {
  const b = req.body || {}
  const {
    contactName,
    contactPhone,
    province,
    city,
    district,
    detail,
    isDefault
  } = b
  if (!contactName || !contactPhone || !province || !city || !district || !detail) {
    return res.status(400).json({ code: 400, message: '请填写完整地址' })
  }
  const conn = await pool.getConnection()
  try {
    await conn.beginTransaction()
    if (isDefault) {
      await conn.query('UPDATE user_addresses SET is_default = 0 WHERE user_id = ?', [req.userId])
    }
    const [r] = await conn.query(
      `INSERT INTO user_addresses
       (user_id, contact_name, contact_phone, province, city, district, detail, is_default)
       VALUES (?,?,?,?,?,?,?,?)`,
      [
        req.userId,
        contactName,
        contactPhone,
        province,
        city,
        district,
        detail,
        isDefault ? 1 : 0
      ]
    )
    await conn.commit()
    const [rows] = await pool.query(
      `SELECT id, contact_name AS contactName, contact_phone AS contactPhone,
              province, city, district, detail, is_default AS isDefault
       FROM user_addresses WHERE id = ?`,
      [r.insertId]
    )
    res.json({ code: 0, data: rows[0] })
  } catch (e) {
    await conn.rollback()
    throw e
  } finally {
    conn.release()
  }
})

router.put('/addresses/:id', async (req, res) => {
  const id = Number(req.params.id)
  const b = req.body || {}
  const {
    contactName,
    contactPhone,
    province,
    city,
    district,
    detail,
    isDefault
  } = b
  const [own] = await pool.query(
    'SELECT id FROM user_addresses WHERE id = ? AND user_id = ?',
    [id, req.userId]
  )
  if (!own.length) {
    return res.status(404).json({ code: 404, message: '地址不存在' })
  }
  const conn = await pool.getConnection()
  try {
    await conn.beginTransaction()
    if (isDefault) {
      await conn.query('UPDATE user_addresses SET is_default = 0 WHERE user_id = ?', [req.userId])
    }
    await conn.query(
      `UPDATE user_addresses SET
        contact_name = ?, contact_phone = ?, province = ?, city = ?, district = ?, detail = ?,
        is_default = ?
       WHERE id = ? AND user_id = ?`,
      [
        contactName,
        contactPhone,
        province,
        city,
        district,
        detail,
        isDefault ? 1 : 0,
        id,
        req.userId
      ]
    )
    await conn.commit()
    const [rows] = await pool.query(
      `SELECT id, contact_name AS contactName, contact_phone AS contactPhone,
              province, city, district, detail, is_default AS isDefault
       FROM user_addresses WHERE id = ?`,
      [id]
    )
    res.json({ code: 0, data: rows[0] })
  } catch (e) {
    await conn.rollback()
    throw e
  } finally {
    conn.release()
  }
})

router.delete('/addresses/:id', async (req, res) => {
  const id = Number(req.params.id)
  const [r] = await pool.query('DELETE FROM user_addresses WHERE id = ? AND user_id = ?', [
    id,
    req.userId
  ])
  if (!r.affectedRows) {
    return res.status(404).json({ code: 404, message: '地址不存在' })
  }
  res.json({ code: 0, data: true })
})

module.exports = router
