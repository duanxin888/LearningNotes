const express = require('express')
const { pool } = require('../db')
const { requireAuth } = require('../middleware/requireAuth')

const router = express.Router()

async function assertDistributor(userId) {
  const [rows] = await pool.query('SELECT role FROM users WHERE id = ?', [userId])
  if (!rows.length || rows[0].role !== 'distributor') {
    const err = new Error('非分销商')
    err.status = 403
    throw err
  }
}

router.get('/distributor/summary', requireAuth, async (req, res) => {
  try {
    await assertDistributor(req.userId)
  } catch (e) {
    return res.status(e.status || 403).json({ code: 403, message: e.message })
  }
  const [[agg]] = await pool.query(
    `SELECT
       COALESCE(SUM(amount_cent), 0) AS totalCent,
       COUNT(*) AS orderCount
     FROM commissions
     WHERE distributor_user_id = ? AND status = 'accrued'`,
    [req.userId]
  )
  res.json({
    code: 0,
    data: {
      totalYuan: (Number(agg.totalCent) / 100).toFixed(2),
      commissionOrderCount: Number(agg.orderCount) || 0,
      userId: req.userId
    }
  })
})

router.get('/distributor/commissions', requireAuth, async (req, res) => {
  try {
    await assertDistributor(req.userId)
  } catch (e) {
    return res.status(e.status || 403).json({ code: 403, message: e.message })
  }
  const [rows] = await pool.query(
    `SELECT c.id,
            c.order_id AS orderId,
            o.out_trade_no AS outTradeNo,
            ROUND(o.total_cent/100,2) AS orderTotalYuan,
            c.amount_cent AS amountCent,
            ROUND(c.amount_cent/100,2) AS amountYuan,
            c.rate_used AS ratePercent,
            c.status,
            c.created_at AS createdAt
     FROM commissions c
     JOIN orders o ON o.id = c.order_id
     WHERE c.distributor_user_id = ?
     ORDER BY c.id DESC
     LIMIT 100`,
    [req.userId]
  )
  res.json({ code: 0, data: rows })
})

module.exports = router
