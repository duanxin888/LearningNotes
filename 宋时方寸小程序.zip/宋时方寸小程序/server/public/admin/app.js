const TOKEN_KEY = 'song_admin_token'

const $ = (sel) => document.querySelector(sel)
const $$ = (sel) => Array.from(document.querySelectorAll(sel))

function token() {
  return localStorage.getItem(TOKEN_KEY) || ''
}

async function api(path, opt = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opt.headers || {}) }
  const t = token()
  if (t) headers.Authorization = `Bearer ${t}`
  const res = await fetch(`/admin/api${path}`, {
    ...opt,
    headers,
    body: opt.body != null ? JSON.stringify(opt.body) : undefined
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const err = new Error(data.message || res.statusText)
    err.data = data
    err.status = res.status
    throw err
  }
  if (data.code !== 0 && data.code !== undefined) {
    const err = new Error(data.message || '请求失败')
    err.data = data
    throw err
  }
  return data
}

function showLogin() {
  $('#app-main').hidden = true
  $('#login-screen').hidden = false
}

function showApp() {
  $('#login-screen').hidden = true
  $('#app-main').hidden = false
}

function setTab(name) {
  $$('.tabs button').forEach((b) => {
    b.classList.toggle('active', b.dataset.tab === name)
  })
  $$('.tab-panel').forEach((p) => {
    p.hidden = p.dataset.panel !== name
  })
}

function toast(msg, ok) {
  const el = $('#toast')
  el.textContent = msg
  el.className = 'msg ' + (ok ? 'ok' : 'err')
  el.hidden = false
  setTimeout(() => {
    el.hidden = true
  }, 3200)
}

async function refreshStats() {
  const { data } = await api('/stats')
  $('#st-orders').textContent = data.orderCount
  $('#st-products').textContent = data.productCount
  $('#st-pending').textContent = data.pendingPay
}

async function loadShop() {
  const { data } = await api('/shop')
  $('#shop-name').value = data.name || ''
  $('#shop-notice').value = data.notice || ''
  $('#shop-desc').value = data.desc || ''
  $('#shop-commission').value =
    data.commissionRatePercent != null ? data.commissionRatePercent : 10
}

async function saveShop() {
  await api('/shop', {
    method: 'PUT',
    body: {
      name: $('#shop-name').value.trim(),
      notice: $('#shop-notice').value.trim(),
      desc: $('#shop-desc').value.trim(),
      commissionRatePercent: Number($('#shop-commission').value || 0)
    }
  })
  toast('店铺信息已保存', true)
}

async function loadUsers() {
  const q = $('#users-q').value.trim()
  const qs = q ? `?q=${encodeURIComponent(q)}` : ''
  const { data } = await api(`/users${qs}`)
  const tb = $('#users-table tbody')
  tb.innerHTML = data
    .map(
      (u) => `<tr>
    <td>${u.id}</td>
    <td>${escapeHtml(u.nickname || '')}</td>
    <td>${escapeHtml(u.role || 'user')}</td>
    <td>${u.referredByUserId != null ? u.referredByUserId : '-'}</td>
    <td class="small">${escapeHtml(String(u.createdAt || ''))}</td>
    <td>
      <button class="btn secondary" data-role-user="${u.id}">设为普通</button>
      <button class="btn secondary" data-role-dist="${u.id}">设为分销</button>
    </td>
  </tr>`
    )
    .join('')
  tb.querySelectorAll('[data-role-user]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.roleUser)
      api(`/users/${id}/role`, { method: 'PUT', body: { role: 'user' } })
        .then(() => {
          toast('已更新为普通用户', true)
          loadUsers()
        })
        .catch((e) => toast(e.message, false))
    })
  })
  tb.querySelectorAll('[data-role-dist]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.roleDist)
      api(`/users/${id}/role`, { method: 'PUT', body: { role: 'distributor' } })
        .then(() => {
          toast('已设为分销商', true)
          loadUsers()
        })
        .catch((e) => toast(e.message, false))
    })
  })
}

async function loadCommissions() {
  const { data } = await api('/commissions?limit=100')
  const tb = $('#comm-table tbody')
  tb.innerHTML = data
    .map(
      (c) => `<tr>
    <td>${c.id}</td>
    <td class="small">${escapeHtml(c.outTradeNo || '')}</td>
    <td>#${c.distributorUserId} ${escapeHtml(c.distributorNickname || '')}</td>
    <td>${c.amountYuan}</td>
    <td>${c.ratePercent}%</td>
    <td class="small">${escapeHtml(String(c.createdAt || ''))}</td>
  </tr>`
    )
    .join('')
}

let categoriesCache = []

async function loadCategories() {
  const { data } = await api('/categories')
  categoriesCache = data
  const sel = $('#p-category')
  sel.innerHTML = data.map((c) => `<option value="${c.id}">${c.name}</option>`).join('')
  const tb = $('#cat-table tbody')
  tb.innerHTML = data
    .map(
      (c) => `<tr>
    <td>${c.id}</td><td>${escapeHtml(c.name)}</td><td>${c.sortOrder}</td>
    <td><button class="btn secondary" data-edit-cat="${c.id}">改</button></td>
  </tr>`
    )
    .join('')
  tb.querySelectorAll('[data-edit-cat]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.editCat)
      const row = categoriesCache.find((x) => x.id === id)
      if (!row) return
      const name = prompt('分类名称', row.name)
      if (name == null) return
      const sortOrder = prompt('排序数字', String(row.sortOrder))
      if (sortOrder == null) return
      api(`/categories/${id}`, { method: 'PUT', body: { name, sortOrder: Number(sortOrder) } })
        .then(() => {
          toast('已更新', true)
          loadCategories()
        })
        .catch((e) => toast(e.message, false))
    })
  })
}

async function addCategory() {
  const name = $('#new-cat-name').value.trim()
  const sortOrder = Number($('#new-cat-sort').value || 0)
  if (!name) return toast('填写分类名', false)
  await api('/categories', { method: 'POST', body: { name, sortOrder } })
  $('#new-cat-name').value = ''
  toast('已添加', true)
  loadCategories()
}

async function loadProducts() {
  const { data } = await api('/products')
  const tb = $('#prod-table tbody')
  tb.innerHTML = data
    .map(
      (p) => `<tr>
    <td>${p.id}</td>
    <td>${escapeHtml(p.name)}</td>
    <td>${p.priceYuan}</td>
    <td>${p.stock}</td>
    <td class="small">${escapeHtml((p.image || '').slice(0, 40))}…</td>
    <td>
      <button class="btn secondary" data-edit-prod="${p.id}">编辑</button>
      <button class="btn danger" data-del-prod="${p.id}">删</button>
    </td>
  </tr>`
    )
    .join('')

  tb.querySelectorAll('[data-edit-prod]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.editProd)
      const { data: list } = await api('/products')
      const p = list.find((x) => x.id === id)
      if (!p) return
      $('#ep-id').value = p.id
      $('#ep-name').value = p.name
      $('#ep-sub').value = p.subtitle || ''
      $('#ep-yuan').value = p.priceYuan
      $('#ep-img').value = p.image
      $('#ep-stock').value = p.stock
      $('#ep-tag').value = p.tag || ''
      $('#ep-detail').value = p.detail || ''
      $('#ep-cat').value = String(p.categoryId)
      $('#prod-editor').hidden = false
    })
  })
  tb.querySelectorAll('[data-del-prod]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.delProd)
      if (!confirm('确定删除商品 #' + id + ' ?')) return
      api(`/products/${id}`, { method: 'DELETE' })
        .then(() => {
          toast('已删除', true)
          loadProducts()
        })
        .catch((e) => toast(e.message, false))
    })
  })
}

async function addProduct() {
  await api('/products', {
    method: 'POST',
    body: {
      categoryId: Number($('#p-category').value),
      name: $('#p-name').value.trim(),
      subtitle: $('#p-sub').value.trim(),
      priceYuan: Number($('#p-yuan').value),
      image: $('#p-img').value.trim(),
      stock: Number($('#p-stock').value || 999),
      tag: $('#p-tag').value.trim() || null,
      detail: $('#p-detail').value.trim() || null
    }
  })
  ;['p-name', 'p-sub', 'p-yuan', 'p-img', 'p-tag', 'p-detail'].forEach((id) => {
    $(`#${id}`).value = ''
  })
  toast('商品已创建', true)
  loadProducts()
}

async function saveEditedProduct() {
  const id = Number($('#ep-id').value)
  await api(`/products/${id}`, {
    method: 'PUT',
    body: {
      categoryId: Number($('#ep-cat').value),
      name: $('#ep-name').value.trim(),
      subtitle: $('#ep-sub').value.trim(),
      priceYuan: Number($('#ep-yuan').value),
      image: $('#ep-img').value.trim(),
      stock: Number($('#ep-stock').value),
      tag: $('#ep-tag').value.trim(),
      detail: $('#ep-detail').value.trim()
    }
  })
  $('#prod-editor').hidden = true
  toast('商品已更新', true)
  loadProducts()
}

async function loadBanners() {
  const { data } = await api('/banners')
  const tb = $('#ban-table tbody')
  tb.innerHTML = data
    .map(
      (b) => `<tr>
    <td>${b.id}</td>
    <td>${escapeHtml(b.title)}</td>
    <td class="small">${escapeHtml((b.image || '').slice(0, 36))}…</td>
    <td>${b.sortOrder}</td>
    <td>
      <button class="btn secondary" data-edit-ban="${b.id}">改</button>
      <button class="btn danger" data-del-ban="${b.id}">删</button>
    </td>
  </tr>`
    )
    .join('')
  tb.querySelectorAll('[data-edit-ban]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.editBan)
      const { data: list } = await api('/banners')
      const b = list.find((x) => x.id === id)
      if (!b) return
      const title = prompt('标题', b.title)
      if (title == null) return
      const subtitle = prompt('副标题', b.subtitle || '') || ''
      const image = prompt('图片 URL', b.image)
      if (image == null) return
      const sortOrder = Number(prompt('排序', String(b.sortOrder)) || 0)
      api(`/banners/${id}`, { method: 'PUT', body: { title, subtitle, image, sortOrder } })
        .then(() => {
          toast('已更新', true)
          loadBanners()
        })
        .catch((e) => toast(e.message, false))
    })
  })
  tb.querySelectorAll('[data-del-ban]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.delBan)
      if (!confirm('删除轮播 #' + id + '?')) return
      api(`/banners/${id}`, { method: 'DELETE' })
        .then(() => {
          toast('已删除', true)
          loadBanners()
        })
        .catch((e) => toast(e.message, false))
    })
  })
}

async function addBanner() {
  await api('/banners', {
    method: 'POST',
    body: {
      title: $('#bn-title').value.trim(),
      subtitle: $('#bn-sub').value.trim(),
      image: $('#bn-img').value.trim(),
      sortOrder: Number($('#bn-sort').value || 0)
    }
  })
  ;['bn-title', 'bn-sub', 'bn-img', 'bn-sort'].forEach((id) => {
    $(`#${id}`).value = ''
  })
  toast('轮播已添加', true)
  loadBanners()
}

let orderPage = 1

async function loadOrders() {
  const { data } = await api(`/orders?page=${orderPage}&limit=20`)
  $('#order-page-info').textContent = `第 ${data.page} 页 / 共 ${data.total} 条`
  const tb = $('#order-table tbody')
  tb.innerHTML = data.list
    .map(
      (o) => `<tr>
    <td>${o.id}</td>
    <td class="small">${escapeHtml(o.outTradeNo)}</td>
    <td>${o.status}</td>
    <td>${o.totalYuan}</td>
    <td class="small">${escapeHtml(String(o.createdAt || ''))}</td>
    <td>${escapeHtml(o.userNickname || '')}</td>
    <td>
      <select data-order-status="${o.id}">
        <option value="pending_pay" ${o.status === 'pending_pay' ? 'selected' : ''}>待支付</option>
        <option value="paid" ${o.status === 'paid' ? 'selected' : ''}>已支付</option>
        <option value="shipped" ${o.status === 'shipped' ? 'selected' : ''}>已发货</option>
        <option value="completed" ${o.status === 'completed' ? 'selected' : ''}>已完成</option>
        <option value="cancelled" ${o.status === 'cancelled' ? 'selected' : ''}>已取消</option>
      </select>
      <button class="btn secondary" data-save-order="${o.id}">保存状态</button>
    </td>
  </tr>`
    )
    .join('')

  tb.querySelectorAll('[data-save-order]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.saveOrder)
      const sel = tb.querySelector(`select[data-order-status="${id}"]`)
      const status = sel.value
      api(`/orders/${id}/status`, { method: 'PATCH', body: { status } })
        .then(() => toast('订单状态已更新', true))
        .catch((e) => toast(e.message, false))
    })
  })
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function fillEpCategories() {
  const sel = $('#ep-cat')
  sel.innerHTML = categoriesCache.map((c) => `<option value="${c.id}">${c.name}</option>`).join('')
}

async function bootMain() {
  showApp()
  await loadCategories()
  fillEpCategories()
  setTab('dash')
  await refreshStats()
}

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault()
  $('#login-err').hidden = true
  try {
    const { data } = await api('/login', {
      method: 'POST',
      body: {
        username: $('#login-user').value.trim(),
        password: $('#login-pass').value
      }
    })
    localStorage.setItem(TOKEN_KEY, data.token)
    await bootMain()
  } catch (err) {
    $('#login-err').textContent = err.message || '登录失败'
    $('#login-err').hidden = false
  }
})

$('#btn-logout').addEventListener('click', () => {
  localStorage.removeItem(TOKEN_KEY)
  showLogin()
})

$$('.tabs button').forEach((b) => {
  b.addEventListener('click', () => {
    const name = b.dataset.tab
    setTab(name)
    if (name === 'dash') refreshStats().catch((e) => toast(e.message, false))
    if (name === 'shop') loadShop().catch((e) => toast(e.message, false))
    if (name === 'cat') loadCategories().catch((e) => toast(e.message, false))
    if (name === 'prod') loadProducts().catch((e) => toast(e.message, false))
    if (name === 'ban') loadBanners().catch((e) => toast(e.message, false))
    if (name === 'ord') loadOrders().catch((e) => toast(e.message, false))
    if (name === 'users') loadUsers().catch((e) => toast(e.message, false))
    if (name === 'comm') loadCommissions().catch((e) => toast(e.message, false))
  })
})

$('#btn-shop-save').addEventListener('click', () => saveShop().catch((e) => toast(e.message, false)))
$('#btn-cat-add').addEventListener('click', () => addCategory().catch((e) => toast(e.message, false)))
$('#btn-prod-add').addEventListener('click', () => addProduct().catch((e) => toast(e.message, false)))
$('#btn-ep-save').addEventListener('click', () => saveEditedProduct().catch((e) => toast(e.message, false)))
$('#btn-ep-cancel').addEventListener('click', () => {
  $('#prod-editor').hidden = true
})
$('#btn-ban-add').addEventListener('click', () => addBanner().catch((e) => toast(e.message, false)))
$('#btn-ord-prev').addEventListener('click', () => {
  if (orderPage > 1) {
    orderPage -= 1
    loadOrders().catch((e) => toast(e.message, false))
  }
})
$('#btn-ord-next').addEventListener('click', () => {
  orderPage += 1
  loadOrders().catch((e) => toast(e.message, false))
})

$('#btn-users-load').addEventListener('click', () => loadUsers().catch((e) => toast(e.message, false)))
$('#btn-comm-load').addEventListener('click', () => loadCommissions().catch((e) => toast(e.message, false)))

;(async () => {
  if (token()) {
    try {
      await api('/stats')
      await bootMain()
    } catch {
      localStorage.removeItem(TOKEN_KEY)
      showLogin()
    }
  } else {
    showLogin()
  }
})()
