CREATE DATABASE IF NOT EXISTS songshop DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE songshop;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  openid VARCHAR(64) NOT NULL UNIQUE,
  unionid VARCHAR(64) NULL,
  nickname VARCHAR(128) NULL,
  avatar_url VARCHAR(512) NULL,
  role VARCHAR(24) NOT NULL DEFAULT 'user' COMMENT 'user|distributor',
  referred_by_user_id INT UNSIGNED NULL DEFAULT NULL COMMENT '永久上级分销商用户 id',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_referred_by (referred_by_user_id),
  CONSTRAINT fk_users_referred_by FOREIGN KEY (referred_by_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_addresses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  contact_name VARCHAR(64) NOT NULL,
  contact_phone VARCHAR(32) NOT NULL,
  province VARCHAR(32) NOT NULL,
  city VARCHAR(32) NOT NULL,
  district VARCHAR(32) NOT NULL,
  detail VARCHAR(255) NOT NULL,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  name VARCHAR(128) NOT NULL,
  subtitle VARCHAR(256) NULL,
  price_cent INT UNSIGNED NOT NULL,
  image VARCHAR(512) NOT NULL,
  stock INT NOT NULL DEFAULT 999,
  tag VARCHAR(16) NULL,
  detail TEXT NULL,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX idx_cat (category_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS banners (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(128) NOT NULL,
  subtitle VARCHAR(256) NULL,
  image VARCHAR(512) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shop_meta (
  `key` VARCHAR(64) PRIMARY KEY,
  `value` TEXT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  out_trade_no VARCHAR(64) NOT NULL UNIQUE,
  status VARCHAR(32) NOT NULL DEFAULT 'pending_pay',
  total_cent INT UNSIGNED NOT NULL,
  address_json JSON NOT NULL,
  referrer_user_id INT UNSIGNED NULL DEFAULT NULL,
  transaction_id VARCHAR(64) NULL,
  prepay_id VARCHAR(128) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  paid_at TIMESTAMP NULL,
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_user_orders (user_id),
  INDEX idx_orders_referrer (referrer_user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS commissions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  distributor_user_id INT UNSIGNED NOT NULL,
  amount_cent INT UNSIGNED NOT NULL,
  rate_used TINYINT UNSIGNED NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'accrued',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_order (order_id),
  INDEX idx_dist (distributor_user_id),
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (distributor_user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  product_name VARCHAR(128) NOT NULL,
  price_cent INT UNSIGNED NOT NULL,
  qty INT UNSIGNED NOT NULL,
  image VARCHAR(512) NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO categories (id, name, sort_order) VALUES
  (1, '香事', 1),
  (2, '茶器', 2),
  (3, '文房', 3),
  (4, '雅物', 4)
ON DUPLICATE KEY UPDATE name=VALUES(name);

INSERT INTO products (category_id, name, subtitle, price_cent, image, stock, tag, detail) VALUES
  (1, '松烟入墨 线香', '书房清供', 6800, 'https://picsum.photos/seed/songxiang1/400/400', 200, '荐', '松烟入墨，静心凝神。'),
  (2, '雨过天青 茶盏', '仿汝窑釉', 19800, 'https://picsum.photos/seed/songcup/400/400', 80, '新', '雨过天青云破处，这般颜色做将来。'),
  (3, '方寸笺 洒金纸', '尺素怀古', 3600, 'https://picsum.photos/seed/songpaper/400/400', 500, NULL, '洒金笺纸，宜书宜画。'),
  (1, '山亭夏日 香囊', '草本配伍', 4800, 'https://picsum.photos/seed/songbag/400/400', 300, NULL, '草本香囊，随身清芬。'),
  (2, '定窑白 茶则', '素器见心', 12800, 'https://picsum.photos/seed/songze/400/400', 120, '荐', '定窑白釉，茶席点睛。'),
  (4, '千里江山 折扇', '绢面竹骨', 15800, 'https://picsum.photos/seed/songfan/400/400', 60, NULL, '绢面折扇，宋韵风雅。');

INSERT INTO banners (title, subtitle, image, sort_order) VALUES
  ('宋时方寸', '以物载道，以寸见山', 'https://picsum.photos/seed/songbanner1/750/360', 1),
  ('春茶上新', '一盏清欢', 'https://picsum.photos/seed/songbanner2/750/360', 2);

INSERT INTO shop_meta (`key`, `value`) VALUES
  ('shop_name', '宋时方寸'),
  ('shop_notice', '宋风器物与文房雅物，现货工作日 48 小时内发货。'),
  ('shop_desc', '对标「人间处方」式商城布局：首页店铺信息、轮播、入口与推荐；分类与列表选购；购物车与微信支付（需配置商户）。'),
  ('commission_rate_percent', '10')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);
