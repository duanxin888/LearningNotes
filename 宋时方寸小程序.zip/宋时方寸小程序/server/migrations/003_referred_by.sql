-- 用户永久上级（分销商）；已有库执行一次
USE songshop;

ALTER TABLE users
  ADD COLUMN referred_by_user_id INT UNSIGNED NULL DEFAULT NULL COMMENT '永久上级分销商用户 id' AFTER role,
  ADD INDEX idx_users_referred_by (referred_by_user_id);

-- 如已存在外键可跳过下一行
ALTER TABLE users
  ADD CONSTRAINT fk_users_referred_by FOREIGN KEY (referred_by_user_id) REFERENCES users (id) ON DELETE SET NULL;
