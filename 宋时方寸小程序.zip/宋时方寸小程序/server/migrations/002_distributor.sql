-- 分销商与订单提成（在已有库上执行一次）
USE songshop;

ALTER TABLE users
  ADD COLUMN role VARCHAR(24) NOT NULL DEFAULT 'user' COMMENT 'user|distributor';

ALTER TABLE orders
  ADD COLUMN referrer_user_id INT UNSIGNED NULL DEFAULT NULL COMMENT '分销商用户 id',
  ADD INDEX idx_orders_referrer (referrer_user_id);

CREATE TABLE IF NOT EXISTS commissions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  distributor_user_id INT UNSIGNED NOT NULL,
  amount_cent INT UNSIGNED NOT NULL,
  rate_used TINYINT UNSIGNED NOT NULL COMMENT '下单时使用的提成比例 1-100',
  status VARCHAR(24) NOT NULL DEFAULT 'accrued',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_order (order_id),
  INDEX idx_dist (distributor_user_id),
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (distributor_user_id) REFERENCES users(id)
) ENGINE=InnoDB;

INSERT INTO shop_meta (`key`, `value`) VALUES ('commission_rate_percent', '10')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);
