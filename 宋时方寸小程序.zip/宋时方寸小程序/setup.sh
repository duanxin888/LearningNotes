#!/bin/bash
# 宋时方寸小程序 - 环境配置脚本

echo "🚀 宋时方寸小程序 - 环境配置"
echo "================================"

PROJECT_ROOT="/Users/shenhong/Downloads/宋时方寸小程序"
SERVER_DIR="$PROJECT_ROOT/server"

# 检查 Node.js
echo ""
echo "📦 检查 Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo "✅ Node.js 已安装：$NODE_VERSION"
else
    echo "❌ Node.js 未安装"
    echo "   请运行：brew install node"
    echo "   或访问：https://nodejs.org"
fi

# 检查 MySQL
echo ""
echo "📦 检查 MySQL..."
if command -v mysql &> /dev/null; then
    echo "✅ MySQL 已安装"
else
    echo "❌ MySQL 未安装"
    echo "   请运行：brew install mysql"
fi

# 配置后端
echo ""
echo "⚙️  配置后端服务器..."
cd "$SERVER_DIR"

if [ ! -f .env ]; then
    echo "📝 创建 .env 配置文件..."
    cp .env.example .env
    echo "✅ .env 已创建"
    echo ""
    echo "⚠️  请编辑 .env 文件配置以下信息："
    echo "   - WECHAT_APPID: 测试号或正式 AppID"
    echo "   - WECHAT_APP_SECRET: AppSecret"
    echo "   - JWT_SECRET: 随机密钥"
    echo ""
    echo "   运行：nano .env"
else
    echo "✅ .env 已存在"
fi

# 安装依赖
echo ""
echo "📦 安装后端依赖..."
if [ -f package.json ]; then
    npm install
    echo "✅ 依赖安装完成"
else
    echo "❌ package.json 未找到"
fi

# 获取本机 IP
echo ""
echo "🌐 本机 IP 地址（用于真机测试）："
ifconfig | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | head -1

echo ""
echo "================================"
echo "✅ 环境配置完成！"
echo ""
echo "下一步："
echo "1. 编辑 $SERVER_DIR/.env 配置微信 AppID 和密钥"
echo "2. 启动后端：cd $SERVER_DIR && npm start"
echo "3. 在微信开发者工具中点击「预览」扫码测试"
echo ""
