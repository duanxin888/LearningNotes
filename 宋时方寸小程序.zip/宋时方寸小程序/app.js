const { API_BASE } = require('./utils/config.js')
const { applyReferrerFromQuery, tryBindPendingReferrer } = require('./utils/referrer.js')

App({
  globalData: {
    apiBase: API_BASE,
    token: '',
    user: null,
    cart: []
  },

  onLaunch(options) {
    applyReferrerFromQuery(options && options.query)
    try {
      this.globalData.token = wx.getStorageSync('token') || ''
    } catch (e) {}
    try {
      const saved = wx.getStorageSync('song_cart')
      if (Array.isArray(saved)) {
        this.globalData.cart = saved
          .map((item) => {
            if (item.productId != null) return item
            if (item.id != null) {
              return {
                productId: item.id,
                name: item.name,
                price: item.price,
                image: item.image,
                qty: item.qty
              }
            }
            return null
          })
          .filter(Boolean)
      }
    } catch (e) {
      this.globalData.cart = []
    }
    this.syncCartBadges()
  },

  onShow(options) {
    applyReferrerFromQuery(options && options.query)
    tryBindPendingReferrer()
  },

  persistCart() {
    try {
      wx.setStorageSync('song_cart', this.globalData.cart)
    } catch (e) {}
    this.syncCartBadges()
  },

  /** @param {{ id:number, name:string, price:number, image:string }} product */
  addToCart(product, qty = 1) {
    const cart = this.globalData.cart
    const pid = product.id
    const hit = cart.find((i) => i.productId === pid)
    if (hit) {
      hit.qty += qty
    } else {
      cart.push({
        productId: pid,
        name: product.name,
        price: product.price,
        image: product.image,
        qty
      })
    }
    this.persistCart()
  },

  setCartQty(productId, qty) {
    const cart = this.globalData.cart
    const idx = cart.findIndex((i) => i.productId === productId)
    if (idx < 0) return
    if (qty <= 0) {
      cart.splice(idx, 1)
    } else {
      cart[idx].qty = qty
    }
    this.persistCart()
  },

  clearCart() {
    this.globalData.cart = []
    this.persistCart()
  },

  syncCartBadges() {
    const n = this.globalData.cart.reduce((s, i) => s + i.qty, 0)
    if (n > 0) {
      wx.setTabBarBadge({ index: 2, text: n > 99 ? '99+' : String(n) })
    } else {
      wx.removeTabBarBadge({ index: 2 })
    }
  },

  getCartTotal() {
    return this.globalData.cart.reduce((s, i) => s + i.price * i.qty, 0)
  }
})
