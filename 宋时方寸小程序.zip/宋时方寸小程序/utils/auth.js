const { request } = require('./request.js')
const { getPendingReferrerId, clearPendingReferrer } = require('./referrer.js')

function loginWithWx() {
  return new Promise((resolve, reject) => {
    wx.login({
      success: async (r) => {
        if (!r.code) {
          reject(new Error('wx.login 无 code'))
          return
        }
        try {
          const pending = getPendingReferrerId()
          const res = await request({
            url: '/api/auth/wx-login',
            method: 'POST',
            data: {
              code: r.code,
              ...(pending ? { referrerId: pending } : {})
            }
          })
          const { token, user } = res.data
          wx.setStorageSync('token', token)
          const app = getApp()
          if (app) {
            app.globalData.token = token
            app.globalData.user = user
          }
          if (user && user.referredByUserId != null) {
            clearPendingReferrer()
          }
          resolve(user)
        } catch (e) {
          reject(e)
        }
      },
      fail: reject
    })
  })
}

async function ensureLogin() {
  const token = wx.getStorageSync('token')
  if (token) {
    const app = getApp()
    if (app) app.globalData.token = token
    return true
  }
  await loginWithWx()
  return true
}

module.exports = { loginWithWx, ensureLogin }
