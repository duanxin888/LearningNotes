const { API_BASE } = require('./config.js')

function request({ url, method = 'GET', data = {}, header = {} }) {
  const token = wx.getStorageSync('token')
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${API_BASE}${url}`,
      method,
      data,
      header: {
        'Content-Type': 'application/json',
        ...header,
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      },
      success(res) {
        const body = res.data
        if (res.statusCode >= 200 && res.statusCode < 300) {
          if (body && typeof body.code === 'number' && body.code !== 0) {
            reject(body)
          } else {
            resolve(body)
          }
        } else {
          reject(body || { message: `HTTP ${res.statusCode}` })
        }
      },
      fail(err) {
        reject(err)
      }
    })
  })
}

module.exports = { request, API_BASE }
