/** 开发时在开发者工具中勾选「不校验合法域名」；上线改为 https 域名并在后台配置 */
const API_BASE = 'http://127.0.0.1:3000'

module.exports = {
  API_BASE
}
