/** 后端不可达时的本地兜底（id 与 MySQL 种子数据一致） */
const products = [
  {
    id: 1,
    name: '松烟入墨 线香',
    subtitle: '书房清供',
    price: 68,
    image: 'https://picsum.photos/seed/songxiang1/400/400',
    categoryId: 1,
    tag: '荐',
    detail: '松烟入墨，静心凝神。',
    stock: 200
  },
  {
    id: 2,
    name: '雨过天青 茶盏',
    subtitle: '仿汝窑釉',
    price: 198,
    image: 'https://picsum.photos/seed/songcup/400/400',
    categoryId: 2,
    tag: '新',
    detail: '雨过天青云破处，这般颜色做将来。',
    stock: 80
  },
  {
    id: 3,
    name: '方寸笺 洒金纸',
    subtitle: '尺素怀古',
    price: 36,
    image: 'https://picsum.photos/seed/songpaper/400/400',
    categoryId: 3,
    tag: '',
    detail: '洒金笺纸，宜书宜画。',
    stock: 500
  },
  {
    id: 4,
    name: '山亭夏日 香囊',
    subtitle: '草本配伍',
    price: 48,
    image: 'https://picsum.photos/seed/songbag/400/400',
    categoryId: 1,
    tag: '',
    detail: '草本香囊，随身清芬。',
    stock: 300
  },
  {
    id: 5,
    name: '定窑白 茶则',
    subtitle: '素器见心',
    price: 128,
    image: 'https://picsum.photos/seed/songze/400/400',
    categoryId: 2,
    tag: '荐',
    detail: '定窑白釉，茶席点睛。',
    stock: 120
  },
  {
    id: 6,
    name: '千里江山 折扇',
    subtitle: '绢面竹骨',
    price: 158,
    image: 'https://picsum.photos/seed/songfan/400/400',
    categoryId: 4,
    tag: '',
    detail: '绢面折扇，宋韵风雅。',
    stock: 60
  }
]

const categories = [
  { id: 1, name: '香事' },
  { id: 2, name: '茶器' },
  { id: 3, name: '文房' },
  { id: 4, name: '雅物' }
]

const banners = [
  {
    id: 1,
    title: '宋时方寸',
    desc: '以物载道，以寸见山',
    image: 'https://picsum.photos/seed/songbanner1/750/360'
  },
  {
    id: 2,
    title: '春茶上新',
    desc: '一盏清欢',
    image: 'https://picsum.photos/seed/songbanner2/750/360'
  }
]

function getProductById(id) {
  const n = Number(id)
  return products.find((p) => p.id === n)
}

function getProductsByCategory(categoryId) {
  const n = Number(categoryId)
  if (!n) return products
  return products.filter((p) => p.categoryId === n)
}

module.exports = {
  products,
  categories,
  banners,
  getProductById,
  getProductsByCategory
}
