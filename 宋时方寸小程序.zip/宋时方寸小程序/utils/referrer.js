/**
 * 分享落地参数 ?rid=分销商用户ID → 写入待绑定上级；登录后写入库 users.referred_by_user_id（仅一次，永久）。
 */
const STORAGE_PENDING = 'song_pending_referrer'
const LEGACY_KEY = 'song_referrer_id'

function migrateLegacyStorage() {
  try {
    const old = wx.getStorageSync(LEGACY_KEY)
    const cur = wx.getStorageSync(STORAGE_PENDING)
    if ((cur == null || cur === '') && old != null && old !== '') {
      wx.setStorageSync(STORAGE_PENDING, old)
      wx.removeStorageSync(LEGACY_KEY)
    }
  } catch (e) {}
}

function applyReferrerFromQuery(query) {
  migrateLegacyStorage()
  if (!query) return
  const raw = query.rid != null ? query.rid : query.referrer
  if (raw === undefined || raw === null || raw === '') return
  const id = parseInt(String(raw), 10)
  if (!id || id < 1) return
  try {
    const existing = wx.getStorageSync(STORAGE_PENDING)
    if (existing != null && existing !== '') return
    wx.setStorageSync(STORAGE_PENDING, id)
  } catch (e) {}
}

function getPendingReferrerId() {
  migrateLegacyStorage()
  try {
    const v = wx.getStorageSync(STORAGE_PENDING)
    if (v === '' || v == null) return null
    const n = parseInt(String(v), 10)
    return n > 0 ? n : null
  } catch (e) {
    return null
  }
}

function clearPendingReferrer() {
  try {
    wx.removeStorageSync(STORAGE_PENDING)
    wx.removeStorageSync(LEGACY_KEY)
  } catch (e) {}
}

/**
 * 已登录时尝试把待绑定上级写入服务端（仅服务端尚无上级时生效）。
 */
function tryBindPendingReferrer() {
  const pending = getPendingReferrerId()
  if (!pending) return Promise.resolve()
  const token = wx.getStorageSync('token')
  if (!token) return Promise.resolve()
  const { request } = require('./request.js')
  return request({
    url: '/api/auth/bind-referrer',
    method: 'POST',
    data: { referrerId: pending }
  })
    .then((res) => {
      const d = (res && res.data) || {}
      if (d.bound || d.reason === 'already' || d.reason === 'distributor') {
        clearPendingReferrer()
      }
    })
    .catch(() => {})
}

module.exports = {
  applyReferrerFromQuery,
  getPendingReferrerId,
  clearPendingReferrer,
  tryBindPendingReferrer
}
