#!/bin/bash
# 宋时方寸小程序 - 一键导入脚本

PROJECT_PATH="/Users/shenhong/Downloads/宋时方寸小程序"
IDE_PATH="/Applications/wechatwebdevtools.app"

echo "🚀 正在导入宋时方寸小程序..."
echo "📂 项目路径：$PROJECT_PATH"

# 检查微信开发者工具是否安装
if [ ! -d "$IDE_PATH" ]; then
    echo "❌ 微信开发者工具未安装"
    exit 1
fi

# 检查项目是否存在
if [ ! -d "$PROJECT_PATH" ]; then
    echo "❌ 项目文件夹不存在"
    exit 1
fi

# 打开微信开发者工具
echo "📱 启动微信开发者工具..."
open -a wechatwebdevtools

# 等待工具启动
sleep 5

# 使用 CLI 打开项目（需要服务端口启用）
echo "🔄 尝试打开项目..."
echo "⚠️  如果 CLI 无法打开项目，请手动操作："
echo "   1. 在微信开发者工具中按 Command + O"
echo "   2. 选择：$PROJECT_PATH"
echo "   3. 点击打开"
echo ""

# 尝试使用 CLI
"$IDE_PATH/Contents/MacOS/cli" open --project "$PROJECT_PATH" 2>&1 &

echo "✅ 完成！"
